from ORION import select_channels


results = select_channels(
    "/Volumes/LaCie/waveforms_das/*.h5",   #****PUT YOUR DAS DATA HERE **** path to one single file or folder (multiple files will be processed in parallel)
    geometry="das_channels_jul_2026.csv",   #path to geometry (Example from the geometry of cable in Kefalonia, Greece, Bozzi et al., 2026)
    output_dir="subsampled_das_data",    #define the path for the output folder
    layout='time_first',  #because the program does not recognize from h5 if the first dimension is time or channels (for mseed yes)
    n_channels=70,  #I want to select 70 channels from the original 7000 channels
    freq_band=(1, 50),  #I don't want to apply a strong pre-filtering
    selection="quality", #apply the quality selection, which is based on SNR, noise level and coherence with neighbouring channels
    stack_width=5,   #stack over a gauge length
    min_spacing=50,  #minimum spacing between selected channels
    dx=2.04, #for k=0, here not used
    min_section_length=50 #minimum lenght of a section is 100 m, as the channel spacing is approx. 2 m
)
results[0].channels       


'''
python3 01_call_orion.py
nohup python3 01_call_orion.py > /dev/null 2>&1 &. #background
'''
