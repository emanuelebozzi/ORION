"""
ORION.py -- automatic DAS channel selection for ORION.

Bozzi, E., Pascucci, G., Rapagnani, G., Bocchini, G. M., Harrington , R., Ugalde, A., Saccorotti , G., & Grigoli, F. (2026). 
Near real-time channel selection for Distributed Acoustic Sensing technology. Seismica, 5(1). 
https://doi.org/10.26443/seismica.v5i1.2251

Select the best N channels of a DAS record and write them to a miniSEED file

How to use it? (from a jupyter notebook cell)
---------------------
    from ORION import select_channels

    results = select_channels(
        "data/*.h5",                 # file, glob, list of files or a folder
        geometry="cable_geometry.txt",   # optional, see below
        output_dir="orion_output",
        n_channels=50,
    )
    print(results[0].channels)       # table of the selected channels
    # -> orion_output/<file name>/selected_channels.mseed  

How to use it? (from the terminal, super basic use)
-----------------------
    python ORION.py data/*.h5 -g cable_geometry.txt -o orion_output -n 50

What do I need to provide?
---------------------------------
* the data file(s)                        (.h5 / .mseed / .npy / .npz / .sac / .segy ...)
* the cable geometry file                 (optional but recommended because ORION looks for channel quality but within cable sections; needs lat/lon columns)
* ``sampling_rate=`` ONLY for formats without metadata (.npy / .npz)
* ``start_time=`` (or ``end_time=``) ONLY when the file carries no time stamp (.npy / .npz, some .h5 /
  .sac / .segy). The start and end time of the record are required in the miniSEED output; when they
  cannot be read from the original file ORION prints a warning and writes a placeholder time (1970).

Everything else (frequency band, window lengths, channel spacing, time/channel
orientation, section size ...) is inferred from the data and printed in the
log so you can see what was chosen. Any of it can be overridden with keyword
arguments, see ``Config``.

Two key channel selection options 
------------------------------------------------
* ``selection="quality"`` (default): the best channels of the cable; poor parts of the cable
  may stay empty.  ``selection="coverage"``: the picks are spread evenly along the WHOLE cable
  and quality only decides which channel is taken inside each interval, even if it is poor.
  ``coverage_tolerance`` (0..1) sets the compromise: 0 = the channel closest to the evenly
  spaced position, 1 = the best channel anywhere in the interval (default 0.5).
* ``stack_width=10``: every output trace is the sum of this many adjacent channels centred
  on the selected one (``stack_width=1`` = single channels, no stacking).
* ``min_section_length=500``: straight cable sections shorter than 500 m (along the cable) are
  not used, like the bends (needs a geometry file; default None = every section is used).
  From the terminal: ``--min-section-length 500``.

Fast version (no plots)
-----------------------
    select_channels("data/*.h5", geometry="cable_geometry.txt", fast=True)
    python ORION.py data/*.h5 -g cable_geometry.txt --fast
The selection and all output files (miniSEED, CSV) are identical; only the two PDF
figures are skipped, so neither the font nor the background map is needed.

Figures
-------
Written as PDF, unless ``fast=True``.

* ``overview.pdf``  : all traces (each one normalised to its own maximum) with the selected
  ones drawn on top, and the quality score per channel in the colours of the cable sections.
* ``cable_map.pdf`` : the cable on a map of the area, axes in longitude/latitude, cable
  coloured by section, selected channels as dark grey triangles.



Geometry file
-------------
Text/CSV with a header line. Delimiter is detected automatically. 
Recognised column names:
    latitude : latitude, lat
    longitude: longitude, lon, lng
    channel  : das_id, channel_id, channel, id      (optional; default = row number)
    or local metric coordinates: x / y  (or easting / northing), in metres.
Degrees may be decimal or DMS strings like  38°10'20.5"N.
Rows must follow the cable order.

Dependencies: numpy, scipy, pandas, matplotlib, obspy, h5py (only for .h5),
basemap + basemap-data-hires (optional, background of the cable map),
contextily (optional, only for web-tile backgrounds).
"""
from __future__ import annotations

import argparse
import ast
import difflib
import glob
import os
import re
import sys
import textwrap
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import matplotlib
import numpy as np
import pandas as pd
from matplotlib.collections import LineCollection
from matplotlib.figure import Figure
from matplotlib.legend_handler import HandlerTuple
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter, MaxNLocator
from obspy import Stream, Trace, UTCDateTime
from obspy import read as obspy_read
from scipy import signal
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from scipy.signal.windows import tukey
from scipy.spatial import cKDTree
from scipy.stats import rankdata

__all__ = ["select_channels", "Config", "OrionResult", "register_reader", "load_geometry"]

_EARTH_R = 6371008.8  # m


# =============================================================================
# Configuration
# =============================================================================
@dataclass
class Config:
    """All options. Only ``n_channels`` (and ``sampling_rate`` for .npy) are
    normally needed; ``None`` means "work it out automatically"."""

    # ---- the basics -------------------------------------------------------
    n_channels: int = 50                         # how many channels to select
    sampling_rate: Optional[float] = None        # Hz; read from file when possible
    start_time: Optional[str] = None             # UTC time of the first sample, e.g. "2024-05-01T12:30:00";
                                                 # read from file when possible (a warning is printed when it cannot)
    end_time: Optional[str] = None               # UTC time of the last sample; alternative to start_time
                                                 # (one of the two is enough, the other follows from the record length)
    freq_band: Optional[Tuple[float, float]] = None  # (low, high) Hz; None = auto
    selection: str = "quality"                   # "quality": best channels | "coverage": evenly spread over the whole cable
                                                 # (coverage ignores subsection_size, min_spacing, include_bends,
                                                 #  trim_percentiles, min_score_percentile)
    stack_width: int = 10                        # adjacent channels summed into each output trace (1 = no stacking)

    # ---- data description (override only if auto-detection is wrong) ------
    dx: Optional[float] = None                   # channel spacing [m]
    layout: str = "auto"                         # "auto" | "channels_first" | "time_first"
    event_time: Optional[float] = None           # event onset [s from start]; None = detect

    # ---- selection behaviour ----------------------------------------------
    subsection_size: Optional[int] = None        # channels per candidate block; None = auto
    min_spacing: int = 10                        # min. distance between selected channels [channels]
    include_bends: bool = False                  # also allow channels on curved parts (outside any straight section)
    min_section_length: Optional[float] = None   # [m] shortest straight cable section kept; shorter ones are
                                                 # treated as bends (no channel picked there unless include_bends=True).
                                                 # Needs a geometry file. None = keep every section
    weights: Tuple[float, float, float] = (1.0, 1.0, 1.0)  # (SNR, coherence, low-noise)
    trim_percentiles: Optional[Tuple[float, float]] = (10.0, 90.0)  # discard outliers; None = off
    min_score_percentile: float = 1.0            # drop blocks scoring below this percentile
    coverage_tolerance: float = 0.5              # selection="coverage": 0 = channel closest to the evenly spaced
                                                 # target position, 1 = best channel in the whole interval
                                                 # (consecutive picks are then >= (1 - tolerance) x interval apart)

    # ---- pre-processing ----------------------------------------------------
    taper: float = 0.01                          # Tukey taper fraction
    k0_cutoff: Optional[float] = None            # [1/m] suppress wavenumbers below this; None = off
    relative_noise: bool = False                 # noise level relative to each trace's own RMS

    # ---- windows (seconds). None = scaled from record length ----------------
    onset_window: Optional[float] = None
    coherence_window: Optional[float] = None
    coherence_neighbors: int = 10                # neighbouring channels used for coherence

    # ---- output --------------------------------------------------------------
    normalize_output: bool = True                # scale each output trace to max |amplitude| = 1
    network: str = "DAS"                         # miniSEED header codes
    channel_code: str = "HHE"
    figures: bool = True                         # PDF figures (vector, publication quality)
    fast: bool = False                           # True = fast version: no figures (same as figures=False)
    basemap: Optional[str] = "coast"             # background of the cable map: "coast" (sea / land / coastline as in
                                                 # the LION plots) | "terrain" | "satellite" | "osm" | "topo" |
                                                 # a contextily provider name | None = no background
    coast_resolution: str = "auto"               # basemap="coast": "auto" | "f" | "h" | "i" | "l" | "c" (full ... crude)
    basemap_zoom: Optional[int] = None           # tile zoom level of the background (None = from the map size)
    verbose: bool = True

    #this handles typical errors in the input parameters 

    def __post_init__(self):
        if self.n_channels < 1:
            raise ValueError("n_channels must be >= 1")
        if self.layout not in ("auto", "channels_first", "time_first"):
            raise ValueError("layout must be 'auto', 'channels_first' or 'time_first'")
        if self.freq_band is not None:
            lo, hi = self.freq_band
            if not 0 < lo < hi:
                raise ValueError("freq_band must be (low, high) with 0 < low < high")
        if len(self.weights) != 3 or min(self.weights) < 0 or sum(self.weights) <= 0:
            raise ValueError("weights must be three non-negative numbers (snr, coherence, noise)")
        if self.selection not in ("quality", "coverage"):
            raise ValueError("selection must be 'quality' or 'coverage'")
        if not 0 <= self.coverage_tolerance <= 1:
            raise ValueError("coverage_tolerance must be between 0 and 1")
        if self.min_section_length is not None and not (np.isfinite(self.min_section_length)
                                                         and self.min_section_length >= 0):
            raise ValueError("min_section_length must be a length in metres >= 0 (or None)")
        if int(self.stack_width) != self.stack_width or self.stack_width < 1:
            raise ValueError("stack_width must be an integer >= 1 (1 = no stacking)")
        self.stack_width = int(self.stack_width)
        if not 0 <= self.taper <= 1:
            raise ValueError("taper must be between 0 and 1")
        for key in ("start_time", "end_time"):
            value = getattr(self, key)
            if value is None:
                continue
            try:
                setattr(self, key, str(UTCDateTime(value)))      # stored as an ISO string (UTC)
            except Exception:
                raise ValueError(f"{key}={value!r} is not a valid time; use UTC in the form "
                                 "'YYYY-MM-DDThh:mm:ss' (decimals of a second allowed)") from None
        if self.fast:
            self.figures = False
        if self.basemap is not None and str(self.basemap).strip().lower() in ("", "none", "off", "false"):
            self.basemap = None


@dataclass
class OrionResult:
    name: str
    output_dir: str
    mseed_path: str
    csv_path: str
    channels: pd.DataFrame                       # one row per selected channel
    info: Dict = field(default_factory=dict)     # parameters actually used


_VERBOSE = True


def _log(msg: str) -> None:
    if _VERBOSE:
        print(msg, flush=True)


def _warn(msg: str) -> None:
    print(f"  ! WARNING: {msg}", file=sys.stderr, flush=True)


# =============================================================================
# Geometry
# =============================================================================
_ALIASES = {
    "lat": ("latitude", "lat"),
    "lon": ("longitude", "lon", "lng", "long"),
    "id": ("das_id", "channel_id", "channel", "chan", "id", "ch"),
    "x": ("x", "easting", "east", "x_m"),
    "y": ("y", "northing", "north", "y_m"),
}


@dataclass
class Geometry:
    ids: np.ndarray                   # channel labels (int)
    east: np.ndarray                  # local coordinates [m]
    north: np.ndarray
    lon: Optional[np.ndarray]
    lat: Optional[np.ndarray]
    dx: float                         # median spacing along the cable [m]

    @property
    def n(self) -> int:
        return len(self.ids)


def _parse_angle(v) -> float:
    """Decimal degrees from a number or a DMS string such as 38°10'20.5"N."""
    if isinstance(v, (int, float, np.number)):
        return float(v)
    s = str(v).strip()
    if not s or s.lower() == "nan":
        return np.nan
    try:
        return float(s.replace(",", "."))
    except ValueError:
        pass
    nums = re.findall(r"\d+(?:\.\d+)?", s)
    if not nums:
        return np.nan
    deg = sum(float(n) / 60 ** i for i, n in enumerate(nums[:3]))
    neg = "-" in s or re.search(r"(^\s*[SsWw])|([SsWw]\s*$)", s) is not None
    return -deg if neg else deg


def _read_table(path: str) -> pd.DataFrame:
    df = None
    try:
        df = pd.read_csv(path, sep=None, engine="python", comment="#")
    except Exception:
        pass
    if df is None or df.shape[1] < 2:
        df = pd.read_csv(path, sep=r"\s+", engine="python", comment="#")
    df.columns = [str(c).strip().lower() for c in df.columns]
    return df


def load_geometry(path: str) -> Geometry:
    """Read a cable geometry file (see module docstring for the format)."""
    df = _read_table(path)
    cols = {c: c for c in df.columns}

    def pick(key):
        return next((a for a in _ALIASES[key] if a in cols), None)

    lat_c, lon_c, x_c, y_c, id_c = pick("lat"), pick("lon"), pick("x"), pick("y"), pick("id")

    if lat_c and lon_c:
        lat = df[lat_c].map(_parse_angle).to_numpy(float)
        lon = df[lon_c].map(_parse_angle).to_numpy(float)
        ok = np.isfinite(lat) & np.isfinite(lon)
        if not ok.all():
            _warn(f"geometry: dropping {(~ok).sum()} rows without valid coordinates")
        df, lat, lon = df[ok], lat[ok], lon[ok]
        lat0, lon0 = lat.mean(), lon.mean()
        east = _EARTH_R * np.cos(np.radians(lat0)) * np.radians(lon - lon0)
        north = _EARTH_R * np.radians(lat - lat0)
    elif x_c and y_c:
        east = df[x_c].to_numpy(float)
        north = df[y_c].to_numpy(float)
        ok = np.isfinite(east) & np.isfinite(north)
        df, east, north = df[ok], east[ok], north[ok]
        lat = lon = None
    else:
        raise ValueError(
            f"Could not find coordinate columns in '{path}'. Found columns: {list(df.columns)}. "
            "Need 'latitude'+'longitude' (or 'x'+'y' in metres) in a header line."
        )

    if id_c is not None:
        raw = pd.to_numeric(df[id_c], errors="coerce").to_numpy(float)
        ids = raw.astype(int) if np.all(np.isfinite(raw)) and np.all(raw == np.round(raw)) else np.arange(len(df))
    else:
        ids = np.arange(len(df))
        if len(ok) != len(ids):  # rows were dropped: keep the original row number as id
            ids = np.flatnonzero(ok)

    if len(ids) < 2:
        raise ValueError("Geometry file has fewer than two valid channels")
    step = np.hypot(np.diff(east), np.diff(north))
    step = step[step > 0]
    dx = float(np.median(step)) if step.size else float("nan")
    return Geometry(ids=ids, east=east, north=north, lon=lon, lat=lat, dx=dx)


# =============================================================================
# Spatial sections (cable segmentation by azimuth)
# =============================================================================
def _knee(y: np.ndarray) -> Optional[int]:
    """Knee of a convex increasing curve (Kneedle idea): point furthest below the chord. 
    Basically it's needed to automatically select the knee in the dbascan eps parameter. The knee is the point where the curve starts to flatten out, which is often used in clustering algorithms to determine the optimal number of clusters or the appropriate distance threshold."""
    if y.size < 3 or y[-1] <= y[0]:
        return None
    yn = (y - y[0]) / (y[-1] - y[0])
    xn = np.linspace(0, 1, y.size)
    d = xn - yn
    k = int(np.argmax(d))
    return k if d[k] > 1e-3 else None


def _contiguous_dbscan(X: np.ndarray, eps: float, min_samples: int, window: int) -> np.ndarray:
    """DBSCAN in which each point only looks for neighbours within +-window positions along the cable,
instead of among all points. A point is core if at least min_samples of these nearby points are
closer than eps. Clusters grow through chains of core points, so each cluster is a stretch of
consecutive channels, and unassigned points get label -1."""
    n = len(X)
    nbrs = []
    for i in range(n):
        lo, hi = max(0, i - window), min(n, i + window + 1)
        d = np.linalg.norm(X[lo:hi] - X[i], axis=1)
        nbrs.append(np.arange(lo, hi)[d <= eps])
    core = np.array([len(a) >= min_samples for a in nbrs])
    labels = np.full(n, -1, dtype=int)
    cid = 0
    for i in range(n):
        if labels[i] != -1 or not core[i]:
            continue
        labels[i] = cid
        stack = [i]
        while stack:
            j = stack.pop()
            if not core[j]:
                continue
            for k in nbrs[j]:
                if labels[k] == -1:
                    labels[k] = cid
                    stack.append(k)
        cid += 1
    return labels


def cluster_cable(geom: Geometry, fallback_size: int = 50,
                  min_length: Optional[float] = None) -> Tuple[np.ndarray, Dict]:
    """Split the cable into straight sections. A window of `chunk` channels slides along the cable,
    and each window is described by its position along the cable and its direction (cos/sin of the
    azimuth). Windows are grouped with a contiguous DBSCAN (eps picked automatically from the
    k-distance knee), so consecutive windows pointing the same way form a section and bends get
    label -1. Sections shorter than min_length can optionally be dropped. If the cable is too short
    or no section is found, it falls back to fixed blocks of fallback_size channels."""
    n = geom.n
    chunk = 10 if n >= 200 else 5

    def fixed(reason):
        _log(f"  sections: {reason} -> fixed blocks of {fallback_size} channels")
        return np.arange(n) // fallback_size, {"method": "fixed", "n_sections": int(np.ceil(n / fallback_size))}

    if n < 4 * chunk:
        return fixed("cable too short for azimuth clustering")

    nwin = n - chunk + 1
    i0 = np.arange(nwin)
    i1 = i0 + chunk - 1
    az = np.arctan2(geom.east[i1] - geom.east[i0], geom.north[i1] - geom.north[i0])
    s = np.concatenate([[0.0], np.cumsum(np.hypot(np.diff(geom.east), np.diff(geom.north)))])
    r = s[i0 + chunk // 2]

    X = np.column_stack([r, np.cos(az), np.sin(az)])
    sd = X.std(axis=0)
    sd[sd < 1e-12] = 1.0
    X = (X - X.mean(axis=0)) / sd

    k = min(chunk, nwin)
    kd = np.sort(cKDTree(X).query(X, k=k)[0][:, -1])
    knee = _knee(kd)
    eps = float(kd[knee]) if knee is not None else float(np.percentile(kd, 90))
    eps = max(eps, 1e-6)

    wl = _contiguous_dbscan(X, eps, min_samples=chunk, window=chunk)
    if wl.max() < 0:
        return fixed("no azimuth cluster found (straight cable?)")

    # window label -> channel label (window centred on the channel)
    labels = wl[np.clip(np.arange(n) - chunk // 2, 0, nwin - 1)]

    # sections shorter than min_length (along the cable) -> no section
    n_dropped = 0
    if min_length is not None and min_length > 0:
        step = np.hypot(np.diff(geom.east), np.diff(geom.north))
        for c in np.unique(labels[labels >= 0]):
            idx = np.flatnonzero(labels == c)
            length = float(s[idx[-1]] - s[idx[0]]) + float(np.median(step))   # channel span + one spacing
            if length < min_length:
                labels[idx] = -1
                n_dropped += 1
        kept = np.unique(labels[labels >= 0])                # renumber 0, 1, 2, ...
        labels = np.where(labels >= 0, np.searchsorted(kept, labels), -1)
        if kept.size == 0:
            _warn(f"min_section_length={min_length:g} m removed every section: no straight section left "
                  "(lower it, or use include_bends=True / selection='coverage')")

    sizes = [int((labels == c).sum()) for c in np.unique(labels[labels >= 0])]
    info = {"method": "azimuth-dbscan", "eps": eps, "n_sections": len(sizes),
            "median_section_size": float(np.median(sizes)) if sizes else 0.0,
            "n_unclustered": int((labels < 0).sum()), "n_dropped_short": n_dropped,
            "min_section_length_m": min_length}
    _log(f"  sections: {len(sizes)} azimuth sections (median {info['median_section_size']:.0f} channels), "
         f"{info['n_unclustered']} channels in no section (eps={eps:.3f})"
         + (f"; {n_dropped} sections shorter than {min_length:g} m dropped" if n_dropped else ""))
    return labels, info


# =============================================================================
# Reading data (this code tries it's best to figure out the file format and read it. It can be further improved by adding more readers for other formats)
# =============================================================================
@dataclass
class DASRecord:
    data: np.ndarray                         # 2-D, orientation not yet known
    fs: Optional[float] = None               # Hz
    dx: Optional[float] = None               # m
    start: Optional[UTCDateTime] = None
    layout: Optional[str] = None             # "channels_first" / "time_first" if the reader knows


_READERS: Dict[str, Callable] = {}


def register_reader(extensions, func: Callable) -> None:
    """Add support for another file format.

    ``func(path)`` must return a 2-D numpy array, or ``(array, meta)`` where
    ``meta`` may contain ``fs`` (Hz), ``dx`` (m), ``start`` (UTCDateTime) and
    ``layout`` ("channels_first"/"time_first"). Example::

        register_reader(".tdms", lambda p: (my_tdms_loader(p), {"fs": 1000}))
    """
    exts = [extensions] if isinstance(extensions, str) else list(extensions)
    for e in exts:
        _READERS[e.lower() if e.startswith(".") else "." + e.lower()] = func


def _read_npy(path: str) -> DASRecord:
    try:
        if path.lower().endswith(".npz"):
            z = np.load(path, allow_pickle=False)
            key = "data" if "data" in z.files else max(z.files, key=lambda k: z[k].size)
            arr = z[key]
        else:
            arr = np.load(path, mmap_mode="r", allow_pickle=False)
    except ValueError as e:
        raise ValueError(f"{path}: cannot load without pickle ({e}). Save a plain numeric array.") from e
    return DASRecord(np.array(arr, dtype=np.float32))


def _read_obspy(path: str) -> DASRecord:
    st = obspy_read(path)
    if len(st) == 0:
        raise ValueError(f"{path}: no traces found")
    st.merge(method=1, fill_value="interpolate")
    if all(tr.stats.station.strip().isdigit() for tr in st):
        st.traces.sort(key=lambda tr: (int(tr.stats.station), tr.stats.channel))
    rates = {round(tr.stats.sampling_rate, 6) for tr in st}
    if len(rates) > 1:
        raise ValueError(f"{path}: traces have different sampling rates {sorted(rates)}")
    t0 = max(tr.stats.starttime for tr in st)
    t1 = min(tr.stats.endtime for tr in st)
    if t1 <= t0:
        raise ValueError(f"{path}: traces do not overlap in time")
    st.trim(t0, t1)
    n = min(tr.stats.npts for tr in st)
    data = np.stack([np.asarray(tr.data[:n], dtype=np.float32) for tr in st])
    return DASRecord(data, fs=float(rates.pop()), start=t0, layout="channels_first")


_FS_KEYS = ("outputdatarate", "samplingfrequency", "samplingrate", "samplerate", "fs")
_DT_KEYS = ("dt", "timestep", "samplinginterval")
_DX_KEYS = ("spatialsamplinginterval", "dx", "channelspacing", "spatialsampling")
_T0_KEYS = ("partstarttime", "starttime", "t0")


def _as_float(v) -> Optional[float]:
    try:
        x = float(np.asarray(v).ravel()[0])
        return x if np.isfinite(x) and x > 0 else None
    except Exception:
        return None


def _parse_time(v) -> Optional[UTCDateTime]:
    try:
        if isinstance(v, np.ndarray):
            v = v.ravel()[0]
        if isinstance(v, bytes):
            v = v.decode()
        return UTCDateTime(v) if isinstance(v, str) else UTCDateTime(float(v))
    except Exception:
        return None


def _read_h5(path: str) -> DASRecord:
    import h5py

    with h5py.File(path, "r") as f:
        found = []

        def visit(name, obj):
            if isinstance(obj, h5py.Dataset) and obj.ndim == 2 and obj.dtype.kind in "iuf":
                found.append(name)

        f.visititems(visit)
        if not found:
            raise ValueError(f"{path}: no 2-D numeric dataset found")
        preferred = ("Acquisition/Raw[0]/RawData", "data", "Data", "raw", "DAS/data")
        name = next((p for p in preferred if p in found), None)
        if name is None:
            name = max(found, key=lambda n: int(np.prod(f[n].shape)))
        data = np.array(f[name], dtype=np.float32)

        # collect attributes from the dataset and all its parent groups (closest wins)
        parts = name.split("/")
        objs = [f[name]] + [f["/".join(parts[:k])] for k in range(len(parts) - 1, 0, -1)] + [f]
        attrs: Dict[str, object] = {}
        for o in objs:
            for k, v in o.attrs.items():
                attrs.setdefault(k.lower().replace(" ", "").replace("_", ""), v)

    fs = next((x for k in _FS_KEYS if k in attrs for x in [_as_float(attrs[k])] if x), None)
    if fs is None:
        dt = next((x for k in _DT_KEYS if k in attrs for x in [_as_float(attrs[k])] if x), None)
        fs = 1.0 / dt if dt else None
    dx = next((x for k in _DX_KEYS if k in attrs for x in [_as_float(attrs[k])] if x), None)
    start = next((t for k in _T0_KEYS if k in attrs for t in [_parse_time(attrs[k])] if t is not None), None)
    return DASRecord(data, fs=fs, dx=dx, start=start)


for _ext in (".h5", ".hdf5", ".hdf"):
    _READERS[_ext] = _read_h5
for _ext in (".npy", ".npz"):
    _READERS[_ext] = _read_npy
for _ext in (".mseed", ".miniseed", ".msd", ".sac", ".sgy", ".segy", ".gse2"):
    _READERS[_ext] = _read_obspy


def read_das_file(path: str) -> DASRecord:
    ext = os.path.splitext(path)[1].lower()
    reader = _READERS.get(ext)
    if reader is None:
        try:  # ObsPy knows many formats; try it before giving up
            return _read_obspy(path)
        except Exception:
            raise ValueError(
                f"Unsupported file type '{ext}' ({path}). Convert to .npy/.h5/.mseed or add a reader "
                "with register_reader()."
            )
    out = reader(path)
    if isinstance(out, DASRecord):
        rec = out
    elif isinstance(out, tuple):
        arr, meta = out
        rec = DASRecord(np.array(arr, dtype=np.float32), **(meta or {}))
    else:
        rec = DASRecord(np.array(out, dtype=np.float32))
    return rec


def _orient(rec: DASRecord, n_geo: Optional[int], layout: str) -> Tuple[np.ndarray, str]:
    """Return data as (channels, samples) and a short note on how this was decided."""
    a = rec.data
    if a.ndim != 2:
        raise ValueError(f"Expected a 2-D array (channels x time), got shape {a.shape}")
    mode, why = layout, "set by user"
    if mode == "auto":
        mode, why = (rec.layout, "known from file format") if rec.layout else ("auto", "")
    if mode == "auto" and n_geo is not None:
        first, second = a.shape[0] == n_geo, a.shape[1] == n_geo
        if first != second:
            mode, why = ("channels_first" if first else "time_first"), "axis length matches geometry"
    if mode == "auto":
        mode = "channels_first" if a.shape[0] <= a.shape[1] else "time_first"
        why = "shorter axis taken as channels (guess)"
        _warn(f"cannot tell the channel axis (no geometry to compare with); assuming {mode} for shape {a.shape}. "
              "Set layout='channels_first' or 'time_first' if this is wrong.")
    out = a if mode == "channels_first" else a.T
    return np.ascontiguousarray(out), f"{mode} ({why})"


def _align(n_data: int, geom: Geometry) -> Tuple[np.ndarray, np.ndarray, str]:
    """Match geometry rows to data rows. Returns (data_rows, geometry_rows, note)."""
    if geom.n == n_data:
        idx = np.arange(n_data)
        return idx, idx, ""
    valid = (geom.ids >= 0) & (geom.ids < n_data)
    geo_rows = np.flatnonzero(valid)
    data_rows = geom.ids[valid]
    if geo_rows.size == 0 or len(np.unique(data_rows)) != len(data_rows):
        m = min(geom.n, n_data)
        geo_rows = data_rows = np.arange(m)
    note = (f"geometry has {geom.n} channels but data has {n_data}; using the {len(geo_rows)} channels "
            "whose ids fit the data")
    return data_rows, geo_rows, note


def _resolve_times(rec: DASRecord, cfg: Config, n_t: int, fs: float,
                   fname: str) -> Tuple[UTCDateTime, UTCDateTime, str]:
    """Absolute time of the first and the last sample of the record.

    Returns (start, end, source) with source = "user" (start_time / end_time option),
    "file" (read from the original file) or "unknown". In the last case a WARNING is
    printed, because the start and end time are required in the miniSEED output, and a
    placeholder time is used so that the selection can still be written.
    """
    span = (n_t - 1) / fs                                   # first sample -> last sample [s]
    # a start time in 1970 is what readers return for a header without a date, not a real DAS time
    file_start = rec.start if rec.start is not None and rec.start.year > 1970 else None

    if cfg.start_time is not None or cfg.end_time is not None:
        if cfg.start_time is not None:
            start = UTCDateTime(cfg.start_time)
            if cfg.end_time is not None:
                given = UTCDateTime(cfg.end_time) - start
                if abs(given - span) > 1.0 / fs:
                    _warn(f"end_time - start_time = {given:.3f} s, but the record is {span:.3f} s long "
                          f"({n_t} samples at {fs:g} Hz); keeping start_time, the end time becomes {start + span}")
        else:
            start = UTCDateTime(cfg.end_time) - span
        if file_start is not None and abs(start - file_start) > 1.0 / fs:
            _warn(f"start time {start} (user) overrides the file's {file_start}")
        return start, start + span, "user"

    if file_start is not None:
        return file_start, file_start + span, "file"

    start = rec.start if rec.start is not None else UTCDateTime(0)
    end = start + span
    _warn(f"the start and end time of the record could not be read from '{fname}'. They are required: "
          f"without them the miniSEED traces carry a placeholder time ({start} to {end}) and cannot be "
          "placed in absolute time (e.g. in LION, or together with other stations). "
          "Pass start_time='YYYY-MM-DDThh:mm:ss' (UTC, time of the first sample) or end_time=... "
          f"(time of the last sample); one of the two is enough, the other follows from the record "
          f"length ({span:.3f} s).")
    return start, end, "unknown"


# =============================================================================
# Pre-processing
# =============================================================================
def _auto_band(fs: float) -> Tuple[float, float]:
    nyq = fs / 2.0
    hi = min(20.0, 0.8 * nyq)
    lo = min(3.0, hi / 4.0)
    return round(lo, 3), round(hi, 3)


def _preprocess(data: np.ndarray, fs: float, band: Tuple[float, float], taper: float,
                k0: Optional[float], dx: Optional[float]) -> None:
    """Detrend, taper, band-pass (and optional low-wavenumber, close to K=0 suppression, typical optical noise in DAS data)"""
    n_ch, n_t = data.shape
    sos = signal.butter(4, band, btype="bandpass", fs=fs, output="sos")
    win = tukey(n_t, taper) if taper > 0 else None
    for a in range(0, n_ch, 256):
        blk = signal.detrend(data[a:a + 256].astype(np.float64), axis=1, type="linear")
        if win is not None:
            blk *= win
        data[a:a + 256] = signal.sosfiltfilt(sos, blk, axis=1)
    if k0:
        if not dx:
            raise ValueError("k0_cutoff needs the channel spacing: pass dx= or provide a geometry file")
        gain = (1.0 - np.exp(-(np.fft.rfftfreq(n_ch, d=dx) / k0) ** 2))[:, None]
        for b in range(0, n_t, 4096):
            spec = np.fft.rfft(data[:, b:b + 4096], axis=0)
            data[:, b:b + 4096] = np.fft.irfft(spec * gain, n=n_ch, axis=0)


# =============================================================================
# Scoring is used to select the best channels within each section. The scores are based on SNR, noise level and coherence with neighbouring channels.
# =============================================================================
def _onset_time(x: np.ndarray, fs: float, win_s: float, step_s: float) -> float:
    """Time [s] where the energy in a sliding window first jumps above everything before it. Try is a first try to automatically detect the onset. Might be improved in the future."""
    win = max(int(win_s * fs), 4)
    step = max(int(step_s * fs), 1)
    c = np.concatenate([[0.0], np.cumsum(x.astype(np.float64) ** 2)])
    i = np.arange(win, len(x) - win, step)
    if i.size < 4:
        return np.nan
    sig_p = (c[i + win] - c[i]) / win
    noi_p = c[i] / i
    snr = 10 * np.log10((sig_p + 1e-30) / (noi_p + 1e-30))
    sm = gaussian_filter1d(snr, 2, mode="nearest")
    # first clear peak: prominent AND at least halfway from the baseline up to the global maximum,
    # so that random transients in the noise before the event are ignored
    base = float(np.median(sm))
    peaks, _ = find_peaks(sm, prominence=1.0, height=base + 0.5 * (sm.max() - base))
    k = int(peaks[0]) if peaks.size else int(np.argmax(sm))
    return float(i[k] / fs)


def _snr_noise(x: np.ndarray, onset: float, fs: float, win_s: float, relative: bool):
    L = int(win_s * fs)
    n = len(x)
    if not np.isfinite(onset) or L < 4 or L >= n:
        return np.nan, np.nan
    s = int(round((onset - win_s / 2) * fs))
    s = min(max(s, 0), n - L)
    noise = x[:s]
    if noise.size < 8:
        return np.nan, np.nan
    npow = float(np.mean(noise.astype(np.float64) ** 2))
    if npow <= 0:
        return np.nan, np.nan
    spow = float(np.mean(x[s:s + L].astype(np.float64) ** 2)) + 1e-30
    snr = 10 * np.log10(spow / npow)
    if relative:
        tot = float(np.mean(x.astype(np.float64) ** 2))
        noise_db = 10 * np.log10(npow / tot)
    else:
        noise_db = 10 * np.log10(npow)
    return snr, noise_db


def _coherence(data: np.ndarray, onsets: np.ndarray, fs: float, win_s: float, n_neigh: int) -> np.ndarray:
    """Mean peak normalised cross-correlation of each channel with its neighbours around the onset."""
    n_ch, n_t = data.shape
    L = int(win_s * fs)
    half = max(n_neigh // 2, 1)
    max_lag = int(min(0.5 * fs, L // 2))
    nfft = 1 << int(np.ceil(np.log2(2 * L)))
    out = np.zeros(n_ch)

    def z(a):
        return (a - a.mean(axis=-1, keepdims=True)) / (a.std(axis=-1, keepdims=True) + 1e-10)

    for c in range(n_ch):
        if not np.isfinite(onsets[c]):
            continue
        s = int(round((onsets[c] - win_s / 2) * fs))
        s = min(max(s, 0), n_t - L)
        nb = [j for j in range(max(0, c - half), min(n_ch, c + half + 1)) if j != c]
        if not nb:
            continue
        ref = z(data[c, s:s + L].astype(np.float64))
        seg = z(data[nb, s:s + L].astype(np.float64))
        cc = np.fft.irfft(np.fft.rfft(seg, nfft) * np.conj(np.fft.rfft(ref, nfft)), nfft)
        lags = np.concatenate([cc[:, :max_lag + 1], cc[:, nfft - max_lag:]], axis=1) / L if max_lag else cc[:, :1] / L
        out[c] = float(np.mean(np.max(np.abs(lags), axis=1)))
    return out


def _inner_mask(v: np.ndarray, trim: Optional[Tuple[float, float]]) -> np.ndarray:
    ok = np.isfinite(v)
    if trim is None or ok.sum() < 3:
        return ok
    a, b = np.percentile(v[ok], trim)
    return ok & (v >= a) & (v <= b)


def _minmax(v: np.ndarray) -> np.ndarray:
    return (v - v.min()) / (np.ptp(v) + 1e-10)


def _rank_scores(snr, noise, coh, weights) -> Tuple[np.ndarray, np.ndarray]:
    """Scores for selection="coverage": percentile ranks (0..1) of each metric among ALL channels
    with finite metrics, combined with the weights. Unlike the "quality" scores nothing is trimmed,
    so the very best channels stay eligible, and extreme values cannot distort the weighting.
    Returns (scores, valid); channels without finite metrics (dead) are not valid and score 0."""
    valid = np.isfinite(snr) & np.isfinite(noise) & np.isfinite(coh)

    def pr(v, sign):
        r = np.zeros(len(v))
        r[valid] = (rankdata(sign * v[valid]) - 1) / max(int(valid.sum()) - 1, 1)
        return r

    return weights[0] * pr(snr, 1) + weights[1] * pr(coh, 1) + weights[2] * pr(noise, -1), valid


# =============================================================================
# Selection
# =============================================================================
def _candidates(scores: np.ndarray, labels: np.ndarray, sub: int, lower_bound: float) -> List[int]:
    """Best channel of every block of ~`sub` channels inside each section."""
    cands = []
    for lb in np.unique(labels[labels >= 0]):
        idx = np.flatnonzero(labels == lb)
        for part in np.array_split(idx, max(1, int(round(idx.size / sub)))):
            if part.size == 0 or scores[part].mean() < lower_bound:
                continue
            best = int(part[np.argmax(scores[part])])
            if scores[best] > 0:
                cands.append(best)
    return cands


def _greedy(cands: List[int], scores: np.ndarray, n: int, min_spacing: int) -> List[int]:
    chosen: List[int] = []
    for c in sorted(cands, key=lambda i: -scores[i]):
        if all(abs(c - s) >= min_spacing for s in chosen):
            chosen.append(c)
            if len(chosen) == n:
                break
    return sorted(chosen)


def _coverage_select(scores: np.ndarray, valid: np.ndarray, pos: np.ndarray, n: int,
                     tolerance: float) -> List[int]:
    """Spread `n` channels as evenly as possible along the cable, accepting low quality.

    The cable (from the first to the last valid channel) is cut into `n` intervals
    of equal length along-cable. In each interval one channel is chosen:
      * only channels that are valid (finite metrics, i.e. not dead) are eligible;
      * the channel has to lie within +-tolerance/2 of the interval length around the
        interval centre (tolerance=1: the whole interval; tolerance=0: the channel
        closest to the centre);
      * among those, the one with the best score wins -- however low that score is.
    If an interval contains no valid channel at all (dead zone), the missing picks are
    added where the largest gaps remain (farthest-point rule).

    scores : per-channel quality score;  valid : bool mask of eligible channels;
    pos : along-cable position of each channel (same length, non-decreasing).
    """
    elig = np.flatnonzero(valid)
    n = int(min(n, elig.size))
    if n == 0:
        return []
    p0, p1 = float(pos[elig[0]]), float(pos[elig[-1]])
    width = (p1 - p0) / n
    chosen: List[int] = []
    for k in range(n):
        lo = p0 + k * width
        hi = p1 if k == n - 1 else p0 + (k + 1) * width      # last interval ends exactly at the last valid channel
        if k == n - 1:
            inside = valid & (pos >= lo) & (pos <= hi)       # ... and includes it
        else:
            inside = valid & (pos >= lo) & (pos < hi)
        cand = np.flatnonzero(inside)
        if cand.size == 0:
            continue
        dist = np.abs(pos[cand] - 0.5 * (lo + hi))
        allowed = cand[dist <= max(0.5 * tolerance * width, dist.min()) + 1e-9 * max(width, 1.0)]
        chosen.append(int(allowed[np.argmax(scores[allowed])]))

    # intervals without any valid channel -> fill the largest remaining gaps
    while len(chosen) < n:
        free = valid.copy()
        free[chosen] = False
        cand = np.flatnonzero(free)
        if cand.size == 0:
            break
        if chosen:
            dmin = np.min(np.abs(pos[cand][:, None] - pos[chosen][None, :]), axis=1)
        else:
            dmin = np.zeros(cand.size)
        best = cand[np.lexsort((-scores[cand], -dmin))[0]]   # largest gap first, ties -> better score
        chosen.append(int(best))
    return sorted(chosen)


# =============================================================================
# Output: miniSEED, CSV
# =============================================================================
def _write_mseed(path, traces, ch_ids, fs, start, cfg):
    st = Stream()
    for tr_data, cid in zip(traces, ch_ids):
        code = str(int(cid))
        if len(code) > 5:
            raise ValueError(f"channel id {cid} does not fit the 5-character miniSEED station code")
        tr = Trace(data=np.ascontiguousarray(tr_data, dtype=np.float32))
        tr.stats.network = cfg.network[:2]
        tr.stats.station = code
        tr.stats.channel = cfg.channel_code[:3]
        tr.stats.starttime = start
        tr.stats.sampling_rate = fs
        st.append(tr)
    st.write(path, format="MSEED")


# =============================================================================
# Figures
# =============================================================================


matplotlib.rc("pdf", fonttype=42)
PDF_DPI = 300                    

_PUB_RC = {
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans"],          # matplotlib default, used when Montserrat is missing
    "font.weight": "normal",
    "axes.labelweight": "normal",
    "axes.titleweight": "normal",
    "font.size": 9,
    "axes.labelsize": 9,
    "axes.titlesize": 11,
    "axes.titlelocation": "center",
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 8,
    "axes.linewidth": 0.8,
    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,
    "xtick.major.size": 3.5,
    "ytick.major.size": 3.5,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "lines.linewidth": 0.6,
    "savefig.dpi": PDF_DPI,
}

# ---- font: Montserrat Regular ------------------------------------------

_FONT_FAMILY = "Montserrat"
_FONT_FILE = "Montserrat-Regular.ttf"
_FONT_URL = "https://raw.githubusercontent.com/JulietaUla/Montserrat/master/fonts/ttf/" + _FONT_FILE
_font_ready: Optional[bool] = None


def _font_is_light(entry) -> bool:
    """Thin / Light / variable cut of the font (same test as in the LION plots)."""
    name = os.path.basename(entry.fname).lower()
    w = entry.weight if isinstance(entry.weight, (int, float)) else 400
    return w < 400 or "[" in name or "variable" in name or re.search(r"thin|light|hairline", name) is not None


def _setup_font() -> bool:
    """Make Montserrat Regular the font matplotlib selects (done once). True if available."""
    global _font_ready
    if _font_ready is not None:
        return _font_ready
    from matplotlib import font_manager as fm

    def usable():
        return [e for e in fm.fontManager.ttflist if e.name == _FONT_FAMILY and not _font_is_light(e)]

    if not usable():                             # no static Regular installed: local copy, else download
        here = Path(__file__).resolve().parent
        cache = Path(matplotlib.get_cachedir()) / "orion_fonts"
        path = next((p for p in (here / "fonts" / _FONT_FILE, here / _FONT_FILE, cache / _FONT_FILE)
                     if p.is_file()), None)
        if path is None:
            try:
                import urllib.request
                cache.mkdir(parents=True, exist_ok=True)
                with urllib.request.urlopen(_FONT_URL, timeout=15) as r:
                    blob = r.read()
                if len(blob) < 10000:
                    raise OSError("unexpected download")
                tmp = cache / (_FONT_FILE + ".part")
                tmp.write_bytes(blob)
                os.replace(tmp, cache / _FONT_FILE)
                path = cache / _FONT_FILE
            except Exception:
                path = None
        if path is not None:
            try:
                fm.fontManager.addfont(str(path))
            except Exception:
                pass
    _font_ready = bool(usable())
    if _font_ready:                              # hide the Thin / Light / variable cuts
        fm.fontManager.ttflist = [e for e in fm.fontManager.ttflist
                                  if not (e.name == _FONT_FAMILY and _font_is_light(e))]
        try:
            fm.fontManager._findfont_cached.cache_clear()
        except Exception:
            pass
    else:
        _warn("Montserrat font not found and could not be downloaded; using the default sans-serif font. "
              f"Install {_FONT_FILE} or put it in a 'fonts' folder next to this script.")
    return _font_ready


def _rc() -> Dict:
    style = dict(_PUB_RC)
    if _setup_font():
        style["font.sans-serif"] = [_FONT_FAMILY] + _PUB_RC["font.sans-serif"]
    return style


# ---- colours shared by the cable map and the quality panel -----------------------------------
_SECTION_COLORS = ["#0072B2", "#E69F00", "#009E73", "#CC79A7", "#56B4E9",
                   "#D55E00", "#7B3294", "#A6A61E", "#8C564B", "#1B9E9E"]
_OUTSIDE_COLOR = "#A8A8A8"       # channels in no section (bends)
_SELECTED_COLOR = "#3A3A3A"      # dark grey triangles


def _section_colors(labels: np.ndarray) -> np.ndarray:
    """One colour per channel: its section's colour (cycling), light grey outside any section."""
    labels = np.asarray(labels).astype(int)
    out = np.array(_SECTION_COLORS)[labels % len(_SECTION_COLORS)]
    out[labels < 0] = _OUTSIDE_COLOR
    return out


def _save_pdf(fig, path, title):
    """Written through PdfPages, as the LION plots (type 42 fonts, 300 dpi, tight box)."""
    from matplotlib.backends.backend_pdf import PdfPages
    with PdfPages(path, metadata={"Title": title, "Creator": "orion_das.py"}) as pdf:
        pdf.savefig(fig, dpi=PDF_DPI, bbox_inches="tight", pad_inches=0.05)


def _plot_overview(path, data, fs, scores, selected, labels, title):
    """(a) all channels as an image, every trace normalised to its own maximum, with the selected
    traces drawn on top; (b) quality score per channel in the colours of the cable sections."""
    n_ch, n_t = data.shape
    sel = np.asarray(selected)
    dc = -(-n_ch // 1600)                       # keep at most ~1600 rows and ~4000 columns in the image
    dt = -(-n_t // 4000)
    view = data[::dc]
    if dt > 1:                                  # anti-aliased down-sampling in time (no aliasing of the wiggles)
        view = signal.resample_poly(view, 1, dt, axis=1)
        wiggles = signal.resample_poly(data[sel], 1, dt, axis=1)
    else:
        wiggles = data[sel]
    norm = view / (np.abs(view).max(axis=1, keepdims=True) + 1e-20)   # each trace: max |amplitude| = 1
    t = np.arange(wiggles.shape[1]) * dt / fs
    colors = _section_colors(labels)
    y = np.arange(n_ch) + 0.5

    with matplotlib.rc_context(_rc()):
        fig = Figure(figsize=(7.2, 5.4))
        gs = fig.add_gridspec(1, 3, width_ratios=[4.5, 1, 0.1], wspace=0.1)   # image | score | colour bar
        ax = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1], sharey=ax)
        cax = fig.add_subplot(gs[2])
        im = ax.imshow(norm, aspect="auto", cmap="RdBu_r", vmin=-1.0, vmax=1.0,
                       extent=[0, n_t / fs, n_ch, 0], interpolation="nearest")
        scale = 0.4 * n_ch / max(len(sel), 1)
        for k, ch in enumerate(sel):
            w = wiggles[k]
            ax.plot(t, ch + 0.5 + scale * w / (np.abs(w).max() + 1e-20), color="k", lw=0.5,
                    label="Selected channels" if k == 0 else None)
        ax.set_xlim(0, n_t / fs)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Channel index")
        ax.set_title(title)
        ax.legend(loc="upper right", frameon=True, framealpha=1.0, edgecolor="0.3", fancybox=False)
        cb = fig.colorbar(im, cax=cax, ticks=[-1, -0.5, 0, 0.5, 1])
        cb.set_label("Amplitude normalized to each trace maximum")

        # score per channel, one colour per cable section (same colours as in the cable map)
        edges = np.flatnonzero(np.diff(np.asarray(labels)) != 0) + 1
        for a, b in zip(np.r_[0, edges], np.r_[edges, n_ch]):
            b = min(b + 1, n_ch)                # reach into the next section so that no gap is left
            ax2.fill_betweenx(y[a:b], 0, scores[a:b], color=colors[a], alpha=0.35, linewidth=0)
            ax2.plot(scores[a:b], y[a:b], color=colors[a], lw=0.8)
        ax2.scatter(scores[sel], y[sel], marker="^", s=16, c=_SELECTED_COLOR, edgecolors="w",
                    linewidths=0.15, zorder=3)
        ax2.set_xlim(0, max(float(np.max(scores)) * 1.08, 1e-6))
        ax2.tick_params(labelleft=False)
        ax2.set_xlabel("Score")
        ax2.set_title("Quality")
        _save_pdf(fig, path, title)


# ---- background map ---------------------------------------------------------------------------
_BASEMAPS = {
    "terrain": "Esri.WorldTopoMap",
    "satellite": "Esri.WorldImagery",
    "osm": "OpenStreetMap.Mapnik",
    "topo": "OpenTopoMap",
}
_basemap_warned = False
_SEA_COLOR, _LAND_COLOR = "lightblue", "whitesmoke"     # as in the LION / LOKI plots
_COAST_CACHE: Dict = {}


def _draw_coast(ax, lon_lim, lat_lim, resolution: str = "auto") -> bool:
    """Simple background as in the LION plots: light blue sea, whitesmoke land, black coastline
    (Basemap, GSHHG coastlines, no internet needed). The normal axis ticks are kept.
    Returns False (plain background) when Basemap is not installed."""
    global _basemap_warned
    try:
        from mpl_toolkits.basemap import Basemap
    except ImportError:
        if not _basemap_warned:
            _warn("no coastline background: install it with 'pip install basemap basemap-data-hires' "
                  "(or set basemap=None)")
            _basemap_warned = True
        return False

    width_km = (lon_lim[1] - lon_lim[0]) * np.radians(_EARTH_R / 1e3) * np.cos(np.radians(np.mean(lat_lim)))
    chain = ["f", "h", "i", "l", "c"]            # full, high, intermediate, low, crude
    want = str(resolution or "auto").lower()
    if want == "auto":
        want = "f" if width_km < 100 else "h"    # a cable needs the finest coastline
    order = chain[chain.index(want):] if want in chain else chain
    # Reading the full-resolution coastline takes ~30 s, so the result is kept: in memory for the
    # other files of this run (same cable -> same map) and on disk for the next runs.
    import hashlib
    import pickle
    m = None
    for res in order:                            # resolutions whose data are not installed are skipped
        key = (res,) + tuple(round(float(v), 6) for v in (*lon_lim, *lat_lim))
        if key in _COAST_CACHE:
            m = _COAST_CACHE[key]
            break
        cache_file = Path(matplotlib.get_cachedir()) / "orion_coast" / (
            hashlib.md5(repr(key).encode()).hexdigest() + ".pkl")
        try:
            with open(cache_file, "rb") as fh:
                m = pickle.load(fh)
        except Exception:
            m = None
        if m is None:
            try:
                if res == "f":
                    _log("  reading the full-resolution coastline (about half a minute, only the first time) ...")
                m = Basemap(projection="cyl", resolution=res, area_thresh=0.0, fix_aspect=False,
                            suppress_ticks=False, llcrnrlon=lon_lim[0], urcrnrlon=lon_lim[1],
                            llcrnrlat=lat_lim[0], urcrnrlat=lat_lim[1])
            except Exception:
                continue
            try:
                cache_file.parent.mkdir(parents=True, exist_ok=True)
                with open(cache_file, "wb") as fh:
                    pickle.dump(m, fh, pickle.HIGHEST_PROTOCOL)
            except Exception:
                pass
        _COAST_CACHE[key] = m
        break
    if m is None:
        _warn("coastline data not found; the cable map is drawn without background")
        return False
    if res != want and not _basemap_warned:
        _warn(f"coastline resolution '{want}' is not installed, using '{res}' "
              "(pip install basemap-data-hires gives the detailed coastline)")
        _basemap_warned = True
    ax.set_facecolor(_SEA_COLOR)
    try:
        m.fillcontinents(color=_LAND_COLOR, lake_color=_SEA_COLOR, ax=ax, zorder=0)
    except Exception:
        pass                                     # no land inside the map
    try:
        m.drawcoastlines(linewidth=0.8, ax=ax, zorder=1)
    except Exception:
        pass
    return True


def _add_basemap(ax, name: str, zoom: Optional[int]) -> Optional[str]:
    """Draw web-map tiles under an axis whose limits are longitude/latitude.
    Returns the attribution text of the tiles, or None if no background could be drawn."""
    global _basemap_warned
    try:
        import contextily as ctx
    except ImportError:
        if not _basemap_warned:
            _warn("no background map: install it with 'pip install contextily' (or set basemap=None)")
            _basemap_warned = True
        return None

    x0, x1 = ax.get_xlim()
    z_auto = min(int(np.ceil(np.log2(3 * 360.0 / max(x1 - x0, 1e-9)))), 17)   # >= 3 tiles across the map
    tries = []
    for n in dict.fromkeys([name, "osm"]):       # the requested map first, OpenStreetMap as a fallback
        try:
            prov = ctx.providers
            for part in _BASEMAPS.get(str(n).lower(), str(n)).split("."):
                prov = prov[part]
            if "url" not in prov:
                raise KeyError(n)
        except (KeyError, AttributeError, TypeError):
            _warn(f"unknown basemap '{n}'; use one of {sorted(_BASEMAPS)} or a contextily provider name")
            continue
        z = int(np.clip(zoom if zoom is not None else z_auto, 0, int(prov.get("max_zoom", 19))))
        tries += [(prov, z)] + ([(prov, z - 2)] if z >= 4 else [])
    err = None
    for prov, z in tries:
        try:
            ctx.add_basemap(ax, crs="EPSG:4326", source=prov, zoom=z, attribution=False,
                            interpolation="bilinear", zorder=0)
            return str(prov.get("attribution", "")) or None
        except Exception as e:                   # no internet, tile server down, zoom not available ...
            err = e
    if not _basemap_warned and err is not None:
        _warn(f"background map could not be downloaded ({type(err).__name__}: {str(err)[:120]}); "
              "the cable map is drawn without it")
        _basemap_warned = True
    return None


def _degree_axis(axis, positive: str, negative: str, nbins: int) -> None:
    """Ticks in decimal degrees with hemisphere letter, e.g. 14.970°E."""
    axis.set_major_locator(MaxNLocator(nbins=nbins, steps=[1, 2, 5, 10]))
    ticks = axis.get_majorticklocs()
    step = float(np.min(np.diff(ticks))) if len(ticks) > 1 else 1.0
    dec = int(max(0, np.ceil(-np.log10(step) - 1e-9)))
    axis.set_major_formatter(FuncFormatter(
        lambda v, _: f"{abs(v):.{dec}f}\u00b0{positive if v >= 0 else negative}"))


def _scale_bar(ax, m_per_unit: float) -> None:
    """Scale bar in the lower left corner with a north arrow above it, drawn as in the LION plots
    (black bracket, 8 pt label, 10 pt 'N', no outline). x axis unit -> metres via m_per_unit."""
    (x0, x1), (y0, y1) = ax.get_xlim(), ax.get_ylim()
    target = 0.25 * (x1 - x0) * m_per_unit
    if np.isfinite(target) and target > 0:
        mag = 10.0 ** np.floor(np.log10(target))
        length = max(f for f in (1, 2, 5) if f * mag <= target) * mag
        xs = x0 + 0.05 * (x1 - x0)
        xe = xs + length / m_per_unit
        yb = y0 + 0.05 * (y1 - y0)
        tick = 0.012 * (y1 - y0)
        ax.plot([xs, xs, xe, xe], [yb + tick, yb, yb, yb + tick], color="k", linewidth=1.5,
                solid_joinstyle="miter", zorder=14)
        label = f"{length / 1000:g} km" if length >= 1000 else f"{length:g} m"
        ax.text(0.5 * (xs + xe), yb + 1.5 * tick, label, ha="center", va="bottom", fontsize=8, zorder=14)
    ax.annotate("", xy=(0.07, 0.24), xytext=(0.07, 0.13), xycoords="axes fraction", zorder=14,
                arrowprops=dict(arrowstyle="-|>", color="k", linewidth=1.5, mutation_scale=14))
    ax.text(0.07, 0.245, "N", transform=ax.transAxes, ha="center", va="bottom", fontsize=10, zorder=14)


def _plot_map(path, east, north, lon, lat, labels, selected, title, basemap=None, zoom=None,
              coast_resolution="auto"):
    """The cable on a map of the area: thick line coloured by section, selected channels as dark
    grey triangles. Axes are longitude/latitude when the geometry has them (else local km)."""
    sel = np.asarray(selected)
    geographic = lon is not None and lat is not None
    if geographic:
        x, y = np.asarray(lon, float), np.asarray(lat, float)
        coslat = max(float(np.cos(np.radians(np.mean(y)))), 1e-6)
        aspect = 1.0 / coslat                                   # 1 deg of latitude drawn 1/cos(lat) x 1 deg of longitude
        m_per_unit = _EARTH_R * np.radians(1.0) * coslat        # metres per degree of longitude
    else:
        x, y = (east - east.mean()) / 1e3, (north - north.mean()) / 1e3
        aspect, m_per_unit = 1.0, 1000.0

    # map frame: the cable plus a margin, never thinner than 70 % of its longer side
    w, h = float(np.ptp(x)), float(np.ptp(y)) * aspect
    size = max(w, h) or 500.0 / m_per_unit
    w, h = max(w, 0.7 * size) + 0.3 * size, max(h, 0.7 * size) + 0.3 * size
    cx, cy = 0.5 * (x.min() + x.max()), 0.5 * (y.min() + y.max())

    with matplotlib.rc_context(_rc()):
        fig_w = 4.8
        fig = Figure(figsize=(fig_w, fig_w * h / w))
        ax = fig.add_subplot(111)
        ax.set_xlim(cx - w / 2, cx + w / 2)
        ax.set_ylim(cy - h / (2 * aspect), cy + h / (2 * aspect))
        ax.set_aspect(aspect, adjustable="box")

        credit = None
        if geographic and basemap:
            if str(basemap).lower() == "coast":
                _draw_coast(ax, ax.get_xlim(), ax.get_ylim(), coast_resolution)
            else:
                credit = _add_basemap(ax, basemap, zoom)

        # cable: hairline white casing + thick line in the section colours
        colors = _section_colors(labels)
        pts = np.column_stack([x, y])
        segs = np.stack([pts[:-1], pts[1:]], axis=1)
        for lw, col, z in ((3.9, "w", 3), (3.2, colors[:-1], 4)):
            lc = LineCollection(segs, colors=col, linewidths=lw, zorder=z)
            for setter in ("set_capstyle", "set_joinstyle"):
                getattr(lc, setter, lambda *_: None)("round")
            ax.add_collection(lc)
        ax.plot(x, y, linestyle="none")          # invisible; lets the legend avoid the cable

        h_sel = ax.scatter(x[sel], y[sel], marker="^", s=40, c=_SELECTED_COLOR, edgecolors="w",
                           linewidths=0.25, zorder=6)

        ax.set_xlim(cx - w / 2, cx + w / 2)
        ax.set_ylim(cy - h / (2 * aspect), cy + h / (2 * aspect))
        if geographic:
            _degree_axis(ax.xaxis, "E", "W", 4)
            _degree_axis(ax.yaxis, "N", "S", 5)
            ax.set_xlabel("Longitude")
            ax.set_ylabel("Latitude")
        else:
            ax.set_xlabel("East (km)")
            ax.set_ylabel("North (km)")
        _scale_bar(ax, m_per_unit)
        ax.set_title(f"{title} \u2013 cable sections")

        # legend: tri-coloured line = cable sections, grey line = outside sections, triangle = selected
        inside = np.asarray(labels) >= 0
        sec_cols = list(dict.fromkeys(colors[inside]))[:3]
        handles, names = [], []
        if sec_cols:
            handles.append(tuple(Line2D([], [], color=c, lw=3.2) for c in sec_cols))
            names.append("Cable sections")
        if (~inside).any():
            handles.append(Line2D([], [], color=_OUTSIDE_COLOR, lw=3.2))
            names.append("Outside sections")
        handles.append(h_sel)
        names.append("Selected channels")
        ax.legend(handles, names, loc="best", frameon=True, framealpha=0.95, edgecolor="0.3", fancybox=False,
                  handler_map={tuple: HandlerTuple(ndivide=None, pad=0.0)}, handlelength=2.4)

        if credit:                               # tile attribution (required by the map providers)
            ax.annotate(textwrap.fill(credit, 95), xy=(0, 0), xycoords="axes fraction", xytext=(0, -34),
                        textcoords="offset points", ha="left", va="top", fontsize=5, color="0.4")
        _save_pdf(fig, path, title)


# =============================================================================
# Main pipeline
# =============================================================================
def _process(name: str, path: str, geom: Optional[Geometry], sections: Optional[np.ndarray],
             cfg: Config, out_dir: str) -> OrionResult:
    # ---- 1. read & orient --------------------------------------------------
    rec = read_das_file(path)
    data, layout_note = _orient(rec, geom.n if geom else None, cfg.layout)
    n_ch, n_t = data.shape
    if not np.isfinite(data).all():
        _warn("NaN/inf values found in data; replacing with 0")
        data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)

    # ---- 2. geometry <-> data ----------------------------------------------
    if geom is not None:
        d_rows, g_rows, note = _align(n_ch, geom)
        if note:
            _warn(note)
        if len(d_rows) != n_ch or not np.array_equal(d_rows, np.arange(n_ch)):
            data = np.ascontiguousarray(data[d_rows])
        ch_ids = geom.ids[g_rows]
        east, north = geom.east[g_rows], geom.north[g_rows]
        lon = geom.lon[g_rows] if geom.lon is not None else None
        lat = geom.lat[g_rows] if geom.lat is not None else None
        labels = sections[g_rows].copy()
        if cfg.include_bends and (labels < 0).any():
            # every contiguous run of unsectioned channels becomes its own section
            run = np.cumsum(np.r_[0, np.diff((labels < 0).astype(int)) != 0])
            labels[labels < 0] = labels.max() + 1 + run[labels < 0]
        n_ch = data.shape[0]
    else:
        ch_ids = np.arange(n_ch)
        east = north = lon = lat = None
        labels = np.arange(n_ch) // 50

    # position of each channel along the cable [m] (channel number if there is no usable geometry)
    pos_along, pos_unit = np.arange(n_ch, dtype=float), "channels"
    if east is not None:
        p = np.concatenate([[0.0], np.cumsum(np.hypot(np.diff(east), np.diff(north)))])
        if p[-1] > 0:
            pos_along, pos_unit = p, "m"

    # ---- 3. resolve parameters ---------------------------------------------
    fs = cfg.sampling_rate or rec.fs
    if not fs:
        raise ValueError(f"Sampling rate unknown for '{os.path.basename(path)}': pass sampling_rate=<Hz>")
    if cfg.sampling_rate and rec.fs and abs(cfg.sampling_rate - rec.fs) > 1e-6 * rec.fs:
        _warn(f"sampling_rate={cfg.sampling_rate} overrides the file's {rec.fs} Hz")
    fs = float(fs)
    dx = cfg.dx or rec.dx or (geom.dx if geom and np.isfinite(geom.dx) else None)
    duration = n_t / fs
    # start / end time of the record: user option > original file > placeholder (with a warning)
    start, end, time_src = _resolve_times(rec, cfg, n_t, fs, os.path.basename(path))
    band = tuple(cfg.freq_band) if cfg.freq_band else _auto_band(fs)
    if band[1] >= fs / 2:
        raise ValueError(f"freq_band {band} must stay below Nyquist ({fs / 2:g} Hz)")
    onset_win = cfg.onset_window or float(np.clip(round(duration / 30, 2), 0.25, 5.0))
    coh_win = cfg.coherence_window or 2 * onset_win
    if coh_win >= duration / 2:
        coh_win = duration / 4
        _warn(f"record is short ({duration:.1f}s); coherence window reduced to {coh_win:.2f}s")
    step = onset_win / 4
    n_neigh = int(min(cfg.coherence_neighbors, max(n_ch - 1, 1)))

    n_labeled = int((labels >= 0).sum())
    if cfg.selection == "quality" and n_labeled == 0:
        raise ValueError("no channel belongs to a straight cable section; use include_bends=True "
                         "or selection='coverage'")
    sub0 = cfg.subsection_size or int(np.clip(round(max(n_labeled, 1) / (1.5 * cfg.n_channels)), 5, 50))

    _log(f"  data: {n_ch} channels x {n_t} samples, {layout_note}")
    _log(f"  fs={fs:g} Hz ({'user' if cfg.sampling_rate else 'file'}), "
         f"dx={'%.2f m' % dx if dx else 'unknown'}, band={band[0]:g}-{band[1]:g} Hz "
         f"({'user' if cfg.freq_band else 'auto'}), duration={duration:.1f}s")
    _log(f"  time: {start} to {end} "
         f"({'NOT IN FILE: placeholder, set start_time=' if time_src == 'unknown' else time_src})")
    _log(f"  windows: onset {onset_win:g}s, coherence {coh_win:g}s, neighbours {n_neigh}")

    # ---- 4. pre-process -----------------------------------------------------
    _preprocess(data, fs, band, cfg.taper, cfg.k0_cutoff, dx)

    # ---- 5. event onset per channel ------------------------------------------
    if cfg.event_time is not None:
        onsets = np.full(n_ch, float(cfg.event_time))
    else:
        raw = np.array([_onset_time(data[c], fs, onset_win, step) for c in range(n_ch)])
        if not np.isfinite(raw).any():
            raise ValueError("could not detect an event onset; record too short? Try event_time=<seconds>")
        raw[~np.isfinite(raw)] = np.nanmedian(raw)
        onsets = gaussian_filter1d(raw, 2)
        _log(f"  detected onset: {np.median(onsets):.2f} s (median over channels)")

    # ---- 6. metrics -----------------------------------------------------------
    snr = np.full(n_ch, np.nan)
    noise = np.full(n_ch, np.nan)
    for c in range(n_ch):
        snr[c], noise[c] = _snr_noise(data[c], onsets[c], fs, coh_win, cfg.relative_noise)
    coh = _coherence(data, onsets, fs, coh_win, n_neigh)

    finite = np.isfinite(snr) & np.isfinite(noise) & np.isfinite(coh)
    if finite.sum() < 3:
        raise ValueError("fewer than 3 channels have valid SNR/coherence (no clear event in this record?)")

    n_want = cfg.n_channels
    sub = None
    if cfg.selection == "coverage":
        # ---- 7a. COVERAGE: spread the picks evenly along the whole cable; quality decides within each interval ----
        if n_want > finite.sum():
            _warn(f"only {int(finite.sum())} channels have valid metrics; selecting that many")
        scores, valid = _rank_scores(snr, noise, coh, cfg.weights)
        chosen = _coverage_select(scores, valid, pos_along, n_want, cfg.coverage_tolerance)
        width = (pos_along[np.flatnonzero(valid)[-1]] - pos_along[np.flatnonzero(valid)[0]]) / max(len(chosen), 1)
        _log(f"  coverage mode: {len(chosen)} intervals of {width:.1f} {pos_unit} along the cable, "
             f"tolerance {cfg.coverage_tolerance:g} (sections, trimming and score thresholds are not used)")
    else:
        # ---- 7b. QUALITY: best channel per block, then the best blocks overall --------------------
        mask = _inner_mask(snr, cfg.trim_percentiles) & _inner_mask(noise, cfg.trim_percentiles) \
            & _inner_mask(coh, cfg.trim_percentiles)
        if mask.sum() < max(n_want, 10):
            _warn("outlier trimming left very few channels; using all channels with valid metrics")
            mask = finite
        s_snr, s_coh, s_noi = np.zeros(n_ch), np.zeros(n_ch), np.zeros(n_ch)
        s_snr[mask] = _minmax(snr[mask])
        s_coh[mask] = _minmax(coh[mask])
        s_noi[mask] = 1 - _minmax(noise[mask])
        w = cfg.weights
        scores = w[0] * s_snr + w[1] * s_coh + w[2] * s_noi

        positive = scores[scores > 0]
        lower = float(np.percentile(positive, cfg.min_score_percentile)) if positive.size else 0.0
        sub, chosen = sub0, []
        while True:
            chosen = _greedy(_candidates(scores, labels, sub, lower), scores, n_want, cfg.min_spacing)
            if len(chosen) >= n_want or sub <= 3 or cfg.subsection_size:
                break
            sub = max(3, sub // 2)
        _log(f"  quality mode: candidate block size {sub} channels")

    if not chosen:
        raise ValueError("no channel could be selected")
    if len(chosen) < n_want:
        _warn(f"only {len(chosen)} of {n_want} requested channels available"
              + ("" if cfg.selection == "coverage" else
                 " (try a smaller min_spacing, trim_percentiles=None, a lower min_score_percentile, "
                 "include_bends=True, or selection='coverage')"))
    sel = np.array(sorted(chosen))
    if cfg.stack_width > 1 and len(sel) > 1 and np.diff(sel).min() < cfg.stack_width:
        _warn(f"some selected channels are closer than stack_width={cfg.stack_width}: their stacks overlap")
    _log(f"  selected {len(sel)} channels (stack width {cfg.stack_width})")

    # ---- 8. write results --------------------------------------------------------
    os.makedirs(out_dir, exist_ok=True)
    before, after = (cfg.stack_width - 1) // 2, cfg.stack_width // 2
    traces = []
    for c in sel:
        tr = data[max(0, c - before):min(n_ch, c + after + 1)].sum(axis=0)
        if cfg.normalize_output:
            tr = tr / (np.abs(tr).max() + 1e-30)
        traces.append(tr)
    mseed_path = os.path.join(out_dir, "selected_channels.mseed")
    _write_mseed(mseed_path, traces, ch_ids[sel], fs, start, cfg)

    table = pd.DataFrame({
        "rank": pd.Series(-scores[sel]).rank(method="first").astype(int).to_numpy(),
        "channel_id": ch_ids[sel],
        "channel_index": sel,
        "section": labels[sel],
        "score": scores[sel],
        "snr_db": snr[sel],
        "coherence": coh[sel],
        "noise_db": noise[sel],
        "onset_s": onsets[sel],
    })
    if lon is not None:
        table.insert(3, "longitude", lon[sel])
        table.insert(4, "latitude", lat[sel])
    elif east is not None:
        table.insert(3, "east_m", east[sel])
        table.insert(4, "north_m", north[sel])
    csv_path = os.path.join(out_dir, "selected_channels.csv")
    table.to_csv(csv_path, index=False, float_format="%.6g")

    every = pd.DataFrame({"channel_id": ch_ids, "channel_index": np.arange(n_ch), "section": labels,
                          "score": scores, "snr_db": snr, "coherence": coh, "noise_db": noise, "onset_s": onsets})
    every.to_csv(os.path.join(out_dir, "channel_scores.csv"), index=False, float_format="%.6g")

    if cfg.stack_width > 1:
        _write_mseed(os.path.join(out_dir, "selected_channels_unstacked.mseed"),
                     [data[c] / (np.abs(data[c]).max() + 1e-30) if cfg.normalize_output else data[c] for c in sel],
                     ch_ids[sel], fs, start, cfg)

    if not cfg.figures:
        _log("  figures skipped (fast version)")
    else:
        _plot_overview(os.path.join(out_dir, "overview.pdf"), data, fs, scores, sel, labels, name)
        if east is not None:
            _plot_map(os.path.join(out_dir, "cable_map.pdf"), east, north, lon, lat, labels, sel, name,
                      basemap=cfg.basemap, zoom=cfg.basemap_zoom,
                      coast_resolution=cfg.coast_resolution)

    info = {"fs": fs, "dx": dx, "band": band, "onset_window": onset_win, "coherence_window": coh_win,
            "coherence_neighbors": n_neigh, "selection": cfg.selection, "block_size": sub, "n_channels_in": n_ch, "n_samples": n_t,
            "start_time": str(start), "end_time": str(end), "time_source": time_src,   # time_source: user | file | unknown
            "layout": layout_note, "config": asdict(cfg)}
    return OrionResult(name=name, output_dir=out_dir, mseed_path=mseed_path, csv_path=csv_path,
                       channels=table, info=info)


def _expand_inputs(data) -> List[str]:
    items = [data] if isinstance(data, (str, os.PathLike)) else list(data)
    exts = set(_READERS)
    files: List[str] = []
    for it in items:
        it = str(it)
        if os.path.isdir(it):
            found = sorted(p for p in glob.glob(os.path.join(it, "*"))
                           if os.path.isfile(p) and os.path.splitext(p)[1].lower() in exts)
        elif any(ch in it for ch in "*?["):
            found = sorted(glob.glob(it))
        else:
            found = [it]
        files.extend(found)
    files = list(dict.fromkeys(files))
    if not files:
        raise FileNotFoundError(f"No data files found for {data!r}")
    missing = [f for f in files if not os.path.isfile(f)]
    if missing:
        raise FileNotFoundError(f"File not found: {missing[0]}")
    return files


def select_channels(data, geometry: Optional[str] = None, output_dir: str = "orion_output",
                    **options) -> List[OrionResult]:
    """Select the best DAS channels and write them to miniSEED.

    Parameters
    ----------
    data : str | list[str]
        File, glob pattern (``"data/*.h5"``), folder, or a list of these.
    geometry : str, optional
        Cable geometry file (see module docstring). Without it the cable is
        cut into fixed 50-channel sections and no map is produced.
    output_dir : str
        One sub-folder per input file is created here.
    **options
        Any field of :class:`Config`, e.g. ``n_channels=30``,
        ``sampling_rate=100`` (needed for .npy), ``freq_band=(2, 30)``,
        ``start_time="2024-05-01T12:30:00"`` (needed when the file has no time stamp).

    Returns
    -------
    list of :class:`OrionResult` (one per successfully processed file).
    """
    global _VERBOSE
    valid = {f.name for f in fields(Config)}
    bad = [k for k in options if k not in valid]
    if bad:
        hints = {k: difflib.get_close_matches(k, valid, n=2) for k in bad}
        raise TypeError("Unknown option(s): " + ", ".join(
            f"{k}" + (f" (did you mean {' / '.join(h)}?)" if h else "") for k, h in hints.items())
            + f". Valid options: {sorted(valid)}")
    cfg = Config(**options)
    _VERBOSE = cfg.verbose

    files = _expand_inputs(data)
    os.makedirs(output_dir, exist_ok=True)
    if len(files) > 1 and (cfg.start_time is not None or cfg.end_time is not None):
        _warn(f"start_time / end_time is applied to all {len(files)} files: every output gets the same time. "
              "Process the files one by one if they were recorded at different times.")

    geom = sections = None
    if geometry:
        _log(f"Geometry: {geometry}")
        geom = load_geometry(geometry)
        _log(f"  {geom.n} channels, median spacing {geom.dx:.2f} m")
        sections, _ = cluster_cable(geom, min_length=cfg.min_section_length)
        pd.DataFrame({"channel_id": geom.ids, "east_m": geom.east, "north_m": geom.north,
                      **({"longitude": geom.lon, "latitude": geom.lat} if geom.lon is not None else {}),
                      "section": sections}).to_csv(os.path.join(output_dir, "sections.csv"), index=False)
    else:
        _log("No geometry given: using fixed 50-channel sections (a geometry file improves the selection)")

    results: List[OrionResult] = []
    failures: List[Tuple[str, str]] = []
    used = set()
    for k, f in enumerate(files, 1):
        name = Path(f).stem
        if name in used:
            name = f"{name}_{k}"
        used.add(name)
        _log(f"\n[{k}/{len(files)}] {os.path.basename(f)}")
        try:
            res = _process(name, f, geom, sections, cfg, os.path.join(output_dir, name))
            results.append(res)
            _log(f"  -> {res.mseed_path}")
        except Exception as e:  # keep going with the other files
            failures.append((f, f"{type(e).__name__}: {e}"))
            print(f"  ! FAILED: {type(e).__name__}: {e}", file=sys.stderr, flush=True)

    _log(f"\nDone: {len(results)} succeeded, {len(failures)} failed. Output in '{output_dir}'")
    if not results:
        raise RuntimeError("All files failed:\n" + "\n".join(f"  {f}: {m}" for f, m in failures))
    return results


# =============================================================================
# Command line
# =============================================================================
def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        description="Automatic DAS channel selection (ORION). Writes selected channels to miniSEED.",
        epilog="Any other Config option: --set NAME=VALUE (repeatable), e.g. --set min_spacing=5 "
               "--set coverage_tolerance=0.2")
    p.add_argument("data", nargs="+", help="file(s), glob pattern(s) or folder(s)")
    p.add_argument("-g", "--geometry", help="cable geometry file (lat/lon per channel)")
    p.add_argument("-o", "--output", default="orion_output", help="output folder (default: orion_output)")
    p.add_argument("-n", "--n-channels", type=int, default=50, help="channels to select (default 50)")
    p.add_argument("--fs", type=float, help="sampling rate in Hz (needed for .npy)")
    p.add_argument("--start-time", metavar="UTC",
                   help="time of the first sample, e.g. 2024-05-01T12:30:00 (needed when the file has no time stamp)")
    p.add_argument("--end-time", metavar="UTC",
                   help="time of the last sample (alternative to --start-time)")
    p.add_argument("--band", type=float, nargs=2, metavar=("LOW", "HIGH"), help="band-pass in Hz (default: auto)")
    p.add_argument("--selection", choices=["quality", "coverage"], default="quality",
                   help="quality: best channels (default); coverage: spread evenly over the whole cable")
    p.add_argument("--min-section-length", type=float, metavar="M",
                   help="shortest straight cable section kept, in metres (default: keep all)")
    p.add_argument("--stack", type=int, default=10, metavar="N",
                   help="number of adjacent channels summed into each output trace (default 10; 1 = no stacking)")
    p.add_argument("--dx", type=float, help="channel spacing in m (default: from file/geometry)")
    p.add_argument("--layout", choices=["auto", "channels_first", "time_first"], default="auto")
    p.add_argument("--event-time", type=float, help="event onset in s from record start (default: detect)")
    p.add_argument("--basemap", default="coast", metavar="NAME",
                   help="background of the cable map: coast (default: sea/land/coastline), terrain, satellite, "
                        "osm, topo, none")
    p.add_argument("--fast", "--no-plots", dest="fast", action="store_true",
                   help="fast version: do not make the PDF figures")
    p.add_argument("--set", action="append", default=[], metavar="NAME=VALUE", help="set any other option")
    p.add_argument("-q", "--quiet", action="store_true")
    a = p.parse_args(argv)

    opts: Dict = {"n_channels": a.n_channels, "layout": a.layout, "verbose": not a.quiet,
                  "selection": a.selection, "stack_width": a.stack, "basemap": a.basemap, "fast": a.fast}
    if a.fs is not None:
        opts["sampling_rate"] = a.fs
    if a.start_time is not None:
        opts["start_time"] = a.start_time
    if a.end_time is not None:
        opts["end_time"] = a.end_time
    if a.band:
        opts["freq_band"] = tuple(a.band)
    if a.dx is not None:
        opts["dx"] = a.dx
    if a.event_time is not None:
        opts["event_time"] = a.event_time
    if a.min_section_length is not None:
        opts["min_section_length"] = a.min_section_length
    for kv in a.set:
        if "=" not in kv:
            p.error(f"--set expects NAME=VALUE, got '{kv}'")
        k, v = kv.split("=", 1)
        try:
            opts[k.strip()] = ast.literal_eval(v)
        except (ValueError, SyntaxError):
            opts[k.strip()] = v
    try:
        select_channels(a.data, geometry=a.geometry, output_dir=a.output, **opts)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())